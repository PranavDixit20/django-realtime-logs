from django.apps import AppConfig # type: ignore

class DjangoRealtimeLogsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_realtime_logs'
